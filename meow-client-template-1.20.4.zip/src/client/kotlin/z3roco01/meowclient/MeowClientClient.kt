package z3roco01.meowclient

import net.fabricmc.api.ClientModInitializer

object MeowClientClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}